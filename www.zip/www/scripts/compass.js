function renderCompass(direction, windSpeed) {
  // Ensure that d3 is available globally
  if (typeof d3 === "undefined") {
    console.error("D3.js library is not loaded.");
    return;
  } else {
    console.log("D3.js library successfully loaded.")
  }

  // Clear the existing SVG if it exists
  d3.select("#windCompass").select("svg").remove();
  
  // Set dimensions
  const width = 150, height = 150, radius = Math.min(width, height) / 2;
  const svg = d3.select("#windCompass").append("svg")
    .attr("width", width)
    .attr("height", height)
    .append("g")
    .attr("transform", `translate(${width / 2},${height / 2})`);

  // Draw outer circle (compass border)
  svg.append("circle")
    .attr("r", radius)
    .attr("stroke", "white")
    .attr("stroke-width", 3)
    .attr("fill", "black");

  // Add cardinal direction labels (N, E, S, W)
  const directions = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"];
  directions.forEach((d, i) => {
    const angle = (i * 45 - 90) * (Math.PI / 180); // Convert to radians
    svg.append("text")
      .attr("x", Math.cos(angle) * (radius - 20))
      .attr("y", Math.sin(angle) * (radius - 20) + 5)
      .attr("text-anchor", "middle")
      .attr("font-size", "14px")
      .attr("fill", "white")
      .text(d);
  });

  // Draw tick marks every 10 degrees
  for (let i = 0; i < 360; i += 10) {
    const angle = (i - 90) * (Math.PI / 180);
    const x1 = Math.cos(angle) * (radius - 5);
    const y1 = Math.sin(angle) * (radius - 5);
    const x2 = Math.cos(angle) * (radius - 15);
    const y2 = Math.sin(angle) * (radius - 15);

    svg.append("line")
      .attr("x1", x1)
      .attr("y1", y1)
      .attr("x2", x2)
      .attr("y2", y2)
      .attr("stroke", "#333")
      .attr("stroke-width", i % 90 === 0 ? 2 : 1); // Thicker lines for cardinal directions
  }

  // Draw the wind direction arrow
  const arrowAngle = (direction + 90) * (Math.PI / 180); // Adjust for compass orientation
  const arrowLength = radius - 20;
  const arrowHeadLength = 20; // Length of the arrow beyond the origin
  svg.append("line")
    .attr("x1", Math.cos(arrowAngle) * -arrowHeadLength)
    .attr("y1", Math.sin(arrowAngle) * -arrowHeadLength)
    .attr("x2", Math.cos(arrowAngle) * (arrowLength - arrowHeadLength))
    .attr("y2", Math.sin(arrowAngle) * (arrowLength - arrowHeadLength))
    .attr("stroke", "white")
    .attr("stroke-width", 3)
    .attr("marker-end", "url(#arrowHead)");

  // Add an arrowhead marker
  svg.append("defs").append("marker")
    .attr("id", "arrowHead")
    .attr("viewBox", "0 -5 10 10")
    .attr("refX", 5)
    .attr("refY", 0)
    .attr("markerWidth", 6)
    .attr("markerHeight", 6)
    .attr("orient", "auto")
    .append("path")
    .attr("d", "M0,-5L10,0L0,5")
    .attr("fill", "white");
  
  // Add wind direction label in the center
  svg.append("text")
    .attr("x", 0)
    .attr("y", 5)
    .attr("text-anchor", "middle")
    .attr("fill", "white")
    .attr("font-size", "12px")  // Default font size for the group
    .append("tspan")
    .attr("x", 0)
    .attr("dy", 0) // Position the first tspan at the starting point
    .attr("font-weight", "bold")  // Larger font size for windSpeed
    .text(`${windSpeed}`)
    .append("tspan")
    .attr("x", 0)
    .attr("dy", "1.2em") // Shift the BFT text slightly below the wind speed text
    .text("BFT");
}

