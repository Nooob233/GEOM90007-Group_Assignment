function setTheme(theme) {
  if (typeof Shiny.setInputValue === 'function') {
    Shiny.setInputValue('theme_select', theme, {priority: 'event'});
  } else if (typeof Shiny.onInputChange === 'function') {
    Shiny.onInputChange('theme_select', theme);
  } else {
    console.error("Shiny.setInputValue or Shiny.onInputChange is not defined.");
  }
}

$(document).on('shiny:connected', function(event) {
  setTheme('Zinc');
});
