// Listener for 'getDirections' message from Shiny
Shiny.addCustomMessageHandler("getDirections", function(data) {
    var startAddress = data.start;
    var endAddress = data.end;

    // Ensure Google Maps and Directions services are loaded
    if (typeof google === 'undefined' || !google.maps) {
        alert("Google Maps API failed to load.");
        return;
    }

    // Create a new map if it doesn't exist
    if (!window.map) {
        window.map = new google.maps.Map(document.getElementById("map"), {
            center: { lat: -37.815, lng: 144.96332 },  // Default center (Melbourne)
            zoom: 12
        });
    }

    // Initialize the Directions service and renderer
    var directionsService = new google.maps.DirectionsService();
    var directionsRenderer = new google.maps.DirectionsRenderer();
    directionsRenderer.setMap(window.map);

    // Set up the directions request
    var request = {
        origin: startAddress,
        destination: endAddress,
        travelMode: google.maps.TravelMode.DRIVING
    };

    // Request directions and handle response
    directionsService.route(request, function(result, status) {
        if (status === google.maps.DirectionsStatus.OK) {
            directionsRenderer.setDirections(result);
        } else {
            alert("Directions request failed due to " + status);
        }
    });
});

